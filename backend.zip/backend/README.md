# SafeRoute Backend (Phase 1 foundation)

Lightweight Express API that sits between the SafeRoute 3D app and
GraphHopper. Current stage: proxies to the **public GraphHopper cloud
API** (with the API key now kept server-side instead of in the client
HTML), plus request validation, rate limiting, duplicate-request
suppression, and a bounded route cache. Self-hosted GraphHopper (Phase G)
is wired in as a configuration switch but is **not yet deployed** — see
`data/README.md`.

## Run it locally

```bash
cd backend
cp .env.example .env
# edit .env and set GRAPHHOPPER_API_KEY to a real key
npm install
npm start
```

Server starts at `http://127.0.0.1:3000` by default (`PORT` in `.env`).

## Endpoints

### `GET /api/route`

```
GET /api/route?startLat=27.3389&startLon=88.6065&endLat=27.3314&endLon=88.6142
```

Required query params: `startLat`, `startLon`, `endLat`, `endLon` (all
numeric; latitudes -90..90, longitudes -180..180).

Response: the **raw GraphHopper response**, unchanged — `data.paths[]`,
each with `points.coordinates`, `instructions`, `distance`, `time`, etc.
This is deliberate: the existing `calculateRoute()` parsing in
`HelloWorld.html` needs zero changes to consume this endpoint.

Response headers:
- `X-SafeRoute-Cache: HIT | MISS`
- `X-SafeRoute-Deduped: true` (present only when this request was served
  by piggybacking on an already-in-flight identical request)

Error responses (JSON body, non-2xx status):
- `400` — missing/invalid parameters
- `429` — rate limited (`Retry-After` header included)
- `502` — upstream GraphHopper error (e.g. its own rate limit)
- `500` — unexpected server error

### `GET /health`

Returns backend status, routing mode, and cache stats. Never returns API
keys or other secrets.

## Switching the app to use this backend

In `HelloWorld.html`, once this backend is deployed somewhere reachable
from the phone:

```js
const ROUTING_CONFIG = {
  mode: "backend",
  graphhopperUrl: "https://graphhopper.com/api/1/route",
  graphhopperKey: GRAPHHOPPER_API_KEY,
  backendUrl: "https://your-backend-host/api/route"
};
```

That's the only change required — `buildRouteUrl()` already branches on
`mode`, and response parsing is unchanged because the schema is identical.

**Do this only after the backend is actually deployed and verified** —
not yet, per this phase's scope.

## Protections implemented

- Per-IP rate limiting (`RATE_LIMIT_WINDOW_MS` / `RATE_LIMIT_MAX_REQUESTS`
  in `.env`) — **Redis-backed and shared across instances when
  `REDIS_URL` is set**, with automatic fallback to the original
  in-memory/single-instance behavior if Redis is unset or unreachable.
- Full coordinate/parameter validation before any upstream call
- In-flight de-duplication — identical concurrent requests share one
  upstream call instead of hammering GraphHopper. Still per-instance
  only (documented limitation — see `services/graphhopper.js`).
- Route cache (`CACHE_TTL_MS` / `CACHE_MAX_ENTRIES`) — **Redis-backed
  and shared across instances when `REDIS_URL` is set**, same
  automatic fallback behavior as rate limiting.
- Request logging (method, path, status, duration) to stdout
- `GET /metrics` — Prometheus text-format counters (requests, cache
  hit/miss, dedup hits, errors, rate-limited count)
- `GET /live` — process liveness only
- `GET /ready` — readiness (routing backend configured); Redis status
  reported but does not fail readiness, since it's an optional
  accelerator with automatic fallback
- API key lives only in `backend/.env` — never sent to the client

## Redis (optional, recommended before horizontally scaling)

Set `REDIS_URL` (e.g. `redis://localhost:6379` or a managed provider's
connection string) and run `npm install` to pull in `ioredis`. With it
set and reachable:
- rate limiting is enforced correctly across ALL backend instances
  sharing that Redis, instead of each instance allowing its own
  independent quota
- the route cache is shared across all instances, so a route already
  computed by instance A is served instantly by instance B on a cache
  hit, instead of every instance independently hitting GraphHopper

Without `REDIS_URL` (or if Redis becomes unreachable mid-session), both
features automatically fall back to the original in-memory,
single-instance-only behavior — nothing crashes or hard-fails.

**Status: CODE INSPECTED + SYNTAX CHECKED, NOT yet run against a real
Redis instance in this session** (no network access in this
environment). Before relying on it: run a real Redis (local `docker run
redis` is the fastest way to check), set `REDIS_URL`, start the server,
and confirm the `[redis] connected` log line and `"cacheBackend":
"redis (shared)"` in `GET /health`.

## Load testing

`backend/loadtest/route-loadtest.js` (autocannon-based) hits `/api/route`
with a realistic mix of repeated Sikkim/Kalimpong coordinate pairs so
cache/dedup paths get exercised the way real traffic would.

```
cd backend
npm install --save-dev autocannon
npm start                 # terminal 1
npm run loadtest          # terminal 2
```

**This has NOT been run in this session** (no network/no live server
here) — it's provided for you to run and is not itself proof of any
throughput number. It characterizes ONE instance; real 700,000-user
readiness requires running it against your actual deployed instance
count and multiplying with real numbers, not assuming linear scaling.

## 700,000-user scalability path (honest status)

**What exists right now:** a single-instance-capable backend that
ALSO supports safe horizontal scaling once Redis is configured (rate
limit + cache are now shared-state-ready). What does **not** yet
exist: multiple instances actually deployed, a real reverse proxy in
front of them, self-hosted GraphHopper, or any load-test evidence at
realistic concurrency. This does **not** by itself serve 700,000
simultaneous users — nobody should claim that without running the load
test above against a real multi-instance deployment.

**Realistic path to get there:**

```
SafeRoute App
      |
Nginx / reverse proxy (TLS termination, load balancing)
  — see deploy/nginx.saferoute.conf.sample —
      |
Multiple backend instances (this codebase, horizontally scaled,
all pointed at the SAME REDIS_URL)
      |
Self-hosted GraphHopper (Phase G — regional OSM data, Phase H)
```

Still required beyond this phase, in rough order:
1. A real VPS/server (not a student laptop) to host the backend + GraphHopper
2. Self-hosted GraphHopper running against the Sikkim+Kalimpong OSM extract
   (removes GraphHopper cloud's free-tier bottleneck entirely)
3. Deploy `deploy/nginx.saferoute.conf.sample` (fill in real domain/TLS)
   in front of multiple backend instances
4. Provision a real Redis (managed, e.g. Upstash/Redis Cloud/ElastiCache,
   or self-hosted) and set `REDIS_URL` identically on every instance —
   the application code is now ready for this; the infrastructure isn't
   provisioned yet
5. Basic uptime/error monitoring (scrape `/metrics`) and backups
6. Run `npm run loadtest` against the real multi-instance deployment at
   realistic concurrency to size actual server resources — 700,000
   *registered* users is not 700,000 *simultaneous* requests, and the
   right server spec depends on the real concurrency number, not the
   total user count

Steps 1, 2, 3, 5 are not built yet. Step 4's application code is ready;
the actual Redis instance is not provisioned. Step 6's script exists
but has not been run.

## What this phase deliberately did NOT touch

- `HelloWorld.html` routing logic/parsing — untouched (see final report)
- Flutter UI, GPS, TTS, hazard/weather/emergency features — untouched
- Distributed in-flight request de-duplication across instances —
  intentionally left per-instance (see `services/graphhopper.js` for
  the reasoning)
- Database readiness / queue architecture — this backend is currently
  stateless (routing proxy + cache only, no persistent data model), so
  there is no database to make "ready" yet; a queue would only be
  needed once a genuinely async workload exists (none does yet)