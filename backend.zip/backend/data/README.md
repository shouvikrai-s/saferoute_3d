# Offline / Local OSM Data (Phase H) — NOT YET DOWNLOADED

Nothing in this folder is populated yet. This is a placeholder describing
exactly what is required so Phase G (self-hosted GraphHopper) can run
against local data instead of the public GraphHopper cloud API.

## What is required

A regional OSM extract (`.osm.pbf`) covering:
- Sikkim (all four districts)
- Kalimpong and the connecting routes between Kalimpong and Sikkim

Geofabrik does not publish a pre-cut "Sikkim" extract — the smallest
official extract that fully contains this region is the **India** extract,
or (recommended, much smaller) a **custom bounding-box extract** cut from
the India `.osm.pbf` using `osmium extract` with a bounding polygon around
Sikkim + Kalimpong. A hand-cut regional extract is typically well under
100 MB, versus several GB for all of India.

Suggested rough bounding box (lon/lat) to hand to `osmium extract
--bbox`, refine before actual use:

```
left   = 88.03
bottom = 26.98
right  = 88.95
top    = 27.90
```

This is a starting box, not verified survey data — adjust to make sure it
fully covers Kalimpong and all four Sikkim districts before cutting.

## Where it should be stored

```
backend/data/sikkim-kalimpong.osm.pbf
```

(git-ignored — regional extracts should not be committed to version
control; document the download step instead, see below).

## How it will be imported

Self-hosted GraphHopper builds its own routing graph from the `.osm.pbf`
on first startup:

```bash
java -Ddw.graphhopper.datareader.file=backend/data/sikkim-kalimpong.osm.pbf \
     -jar graphhopper-web-<version>.jar server config.yml
```

This produces a `graph-cache/` folder (also git-ignored) that GraphHopper
reuses on subsequent restarts unless the `.osm.pbf` changes.

## How the backend will use it

Once self-hosted GraphHopper is actually running and reachable (e.g.
`http://127.0.0.1:8989`), set in `backend/.env`:

```
ROUTING_MODE=self_hosted
GRAPHHOPPER_SELF_HOSTED_URL=http://127.0.0.1:8989/route
```

`backend/services/graphhopper.js` already supports this mode — no code
change needed, only configuration.

## Current status

- [ ] `.osm.pbf` extract downloaded/cut for Sikkim + Kalimpong
- [ ] Self-hosted GraphHopper installed and run locally
- [ ] `graph-cache/` built successfully
- [ ] `ROUTING_MODE=self_hosted` verified against real requests

None of the above is done yet. Do not treat this phase as complete until
every box above is checked against a real, working local GraphHopper
instance.
