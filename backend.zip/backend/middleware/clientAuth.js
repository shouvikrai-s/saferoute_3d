// Abuse-reduction check for /api/route (Phase 11, Step 4).
//
// HONEST SCOPE, stated plainly rather than oversold: this checks for a
// static key embedded in the shipped Flutter/WebView client. Anyone who
// decompiles the APK or inspects WebView network traffic can extract
// this same key and impersonate the app. This is NOT cryptographic
// protection against a determined reverse-engineer — it is a low-cost
// filter against casual/scripted scraping of the bare public endpoint
// (e.g. a bot that finds the URL and hits it directly, never having
// looked at the app at all). Combined with the existing per-IP rate
// limiter, this covers the realistic threat model for a public,
// login-free app with no budget for stronger auth infrastructure.
//
// The expected value lives in server-side environment configuration
// (SAFEROUTE_CLIENT_KEY in .env) — never hardcoded here — so it can be
// rotated without a code change or app rebuild being strictly required
// (the client's copy still needs updating to match, but the server
// side is configuration, not source).

const EXPECTED_KEY = process.env.SAFEROUTE_CLIENT_KEY || "";

function requireClientKey(req, res, next) {
  if (!EXPECTED_KEY) {
    // No key configured server-side — fail OPEN with a clear log, not
    // silently. This matches the "graceful fallback, never a hard
    // outage" pattern already used for Redis in this backend: a
    // missing optional-hardening config shouldn't take routing down,
    // but it must be visible that the check isn't actually active.
    console.warn(
      "[auth] SAFEROUTE_CLIENT_KEY is not set in the environment — " +
      "client-key check is DISABLED. Set it in backend/.env before " +
      "relying on this as an abuse-reduction layer."
    );
    return next();
  }

  const provided = req.get("X-SafeRoute-Client-Key");
  if (provided !== EXPECTED_KEY) {
    return res.status(401).json({
      error: "unauthorized",
      message: "Missing or invalid client credential.",
    });
  }

  next();
}

module.exports = { requireClientKey };