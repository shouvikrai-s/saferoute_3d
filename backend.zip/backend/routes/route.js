const express = require("express");
const { validateRouteQuery } = require("../middleware/requestValidation");
const { requireClientKey } = require("../middleware/clientAuth");
const { rateLimit } = require("../middleware/rateLimit");
const graphhopper = require("../services/graphhopper");
const metrics = require("../services/metrics");

const router = express.Router();

// GET /api/route?startLat=..&startLon=..&endLat=..&endLon=..
router.get(
  "/route",
  requireClientKey,
  rateLimit,
  validateRouteQuery,
  async (req, res) => {
    const { startLat, startLon, endLat, endLon } = req.routeParams;

    metrics.incr("route_requests_total");

    try {
      const { data, cacheHit, deduped } = await graphhopper.getRoute(
        startLat,
        startLon,
        endLat,
        endLon
      );

      if (cacheHit) {
        metrics.incr("route_cache_hits_total");
      } else {
        metrics.incr("route_cache_misses_total");
      }

      if (deduped) {
        metrics.incr("route_dedup_hits_total");
      }

      res.set("X-SafeRoute-Cache", cacheHit ? "HIT" : "MISS");

      if (deduped) {
        res.set("X-SafeRoute-Deduped", "true");
      }

      if (
        !data ||
        !Array.isArray(data.paths) ||
        data.paths.length === 0
      ) {
        return res.status(200).json(
          data || {
            paths: [],
            message: "No route could be found.",
          }
        );
      }

      return res.status(200).json(data);
    } catch (err) {
      metrics.incr("route_errors_total");

      console.error("[/api/route] error:", err.message);

      if (err.circuitOpen || err.capacityExhausted) {
        // Phase 1 addition: these are OUR OWN protective conditions
        // (circuit breaker open, or bounded queue full), not an actual
        // error response from GraphHopper — 503 (Service Unavailable,
        // temporary/retry-able) is the honest signal here, distinct
        // from the 502 used below for genuine upstream failures.
        return res.status(503).json({
          error: err.circuitOpen ? "circuit_open" : "capacity_exhausted",
          message: "The routing service is temporarily at capacity. Please try again shortly.",
        });
      }

      if (err.upstreamStatus) {
        return res.status(502).json({
          error: "upstream_routing_error",
          message: "The routing service could not process this request.",
        });
      }

      return res.status(500).json({
        error: "internal_error",
        message: "Could not calculate a route. Please try again.",
      });
    }
  }
);

module.exports = router;