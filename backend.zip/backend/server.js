require("dotenv").config();

const db = require("./services/db");

const express = require("express");
const os = require("os");
const routeRouter = require("./routes/route");
const graphhopper = require("./services/graphhopper");
const redis = require("./services/redisClient");
const metrics = require("./services/metrics");

const app = express();
const PORT = Number(process.env.PORT || 3000);

// ---------------------------------------------------------------------
// PROXY TRUST
// ---------------------------------------------------------------------
// Currently there is no trusted reverse proxy directly in front of
// this Node process, so Express keeps its default trust-proxy behavior.
// Do NOT use app.set("trust proxy", true) here.
//
// Later, when a real reverse proxy is deployed, trust only the known
// proxy/subnet.
// ---------------------------------------------------------------------

// ---------------------------------------------------------------------
// BASIC REQUEST LOGGING
// ---------------------------------------------------------------------
// Logs method, path, status and duration.
// req.path is deliberately used instead of req.originalUrl so route
// coordinates are not written into logs.
// ---------------------------------------------------------------------
app.use((req, res, next) => {
  const startedAt = Date.now();

  res.on("finish", () => {
    const durationMs = Date.now() - startedAt;

    metrics.incr("http_requests_total");
    metrics.incrStatus(res.statusCode);

    console.log(
      `${new Date().toISOString()} ${req.method} ${req.path} -> ${res.statusCode} (${durationMs}ms)`
    );
  });

  next();
});

// ---------------------------------------------------------------------
// SECURITY HEADERS
// ---------------------------------------------------------------------
// HSTS is intentionally NOT enabled because this Node server currently
// serves plain HTTP on the LAN.
// ---------------------------------------------------------------------
app.use((req, res, next) => {
  res.set("X-Content-Type-Options", "nosniff");
  res.set("X-Frame-Options", "DENY");
  res.set("Referrer-Policy", "no-referrer");
  next();
});

// ---------------------------------------------------------------------
// CORS
// ---------------------------------------------------------------------
app.use((req, res, next) => {
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.set(
    "Access-Control-Allow-Headers",
    "Content-Type, X-SafeRoute-Client-Key"
  );

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  next();
});

// ---------------------------------------------------------------------
// API ROUTES
// ---------------------------------------------------------------------
app.use("/api", routeRouter);

// ---------------------------------------------------------------------
// GET /api/nearby/locations
// ---------------------------------------------------------------------
app.get("/api/nearby/locations", async (req, res) => {
  try {
    const lat = Number(req.query.lat);
    const lon = Number(req.query.lon);
    const radius = Number(req.query.radius || 5000);

    if (
      !Number.isFinite(lat) ||
      !Number.isFinite(lon) ||
      !Number.isFinite(radius) ||
      lat < -90 ||
      lat > 90 ||
      lon < -180 ||
      lon > 180 ||
      radius <= 0 ||
      radius > 50000
    ) {
      return res.status(400).json({
        error: "invalid_request",
        message:
          "lat, lon and radius are required. Radius must be between 1 and 50000 meters.",
      });
    }

    const result = await db.query(
      `
      SELECT
        id,
        name,
        category,
        description,
        latitude,
        longitude,
        ST_Distance(
          location,
          ST_SetSRID(
            ST_MakePoint($2, $1),
            4326
          )::geography
        ) AS distance_meters
      FROM saferoute_locations
      WHERE location IS NOT NULL
        AND ST_DWithin(
          location,
          ST_SetSRID(
            ST_MakePoint($2, $1),
            4326
          )::geography,
          $3
        )
      ORDER BY distance_meters ASC
      LIMIT 100;
      `,
      [lat, lon, radius]
    );

    res.status(200).json({
      status: "ok",
      count: result.rows.length,
      radiusMeters: radius,
      locations: result.rows,
    });
  } catch (error) {
    console.error(
      "[nearby-locations] PostgreSQL query failed:",
      error.message
    );

    res.status(500).json({
      error: "database_error",
      message: "Unable to query nearby locations.",
    });
  }
});
// ---------------------------------------------------------------------
// GET /health/db
// ---------------------------------------------------------------------
// PostgreSQL database health check.
//
// Returns HTTP 200 when PostgreSQL accepts a simple query.
// Returns HTTP 503 if PostgreSQL is unavailable.
//
// Never exposes database password or connection details.
// ---------------------------------------------------------------------
app.get("/health/db", async (req, res) => {
  try {
    await db.query("SELECT 1");

    res.status(200).json({
      status: "ok",
      database: "postgresql",
    });
  } catch (error) {
    console.error(
      "[db-health] PostgreSQL check failed:",
      error.message
    );

    res.status(503).json({
      status: "error",
      database: "postgresql",
    });
  }
});

// ---------------------------------------------------------------------
// GET /metrics
// ---------------------------------------------------------------------
app.get("/metrics", (req, res) => {
  res.set("Content-Type", "text/plain; version=0.0.4");
  res.status(200).send(metrics.renderPrometheus());
});

// ---------------------------------------------------------------------
// GET /live
// ---------------------------------------------------------------------
// Process-level liveness.
// Does not check external dependencies.
// ---------------------------------------------------------------------
app.get("/live", (req, res) => {
  res.status(200).json({
    status: "ok",
  });
});

// ---------------------------------------------------------------------
// GET /ready
// ---------------------------------------------------------------------
// Readiness check.
//
// Routing must be configured.
// Redis is informational only because the routing system has a fallback.
// ---------------------------------------------------------------------
app.get("/ready", (req, res) => {
  if (shuttingDown) {
    return res.status(503).json({
      status: "not_ready",
      reason: "shutting_down",
    });
  }

  const routingStatus = graphhopper.getStatus();

  const isReady =
    routingStatus.cloudConfigured ||
    routingStatus.selfHostedConfigured;

  res.status(isReady ? 200 : 503).json({
    status: isReady ? "ready" : "not_ready",

    routing: {
      mode: routingStatus.mode,
      cloudConfigured: routingStatus.cloudConfigured,
      selfHostedConfigured: routingStatus.selfHostedConfigured,
    },

    redis: {
      configured: Boolean(process.env.REDIS_URL),
      connected: redis.isAvailable(),
      note:
        "Informational only — Redis is optional and does not affect readiness.",
    },
  });
});

// ---------------------------------------------------------------------
// 404 HANDLER
// ---------------------------------------------------------------------
app.use((req, res) => {
  res.status(404).json({
    error: "not_found",
    message: "Unknown endpoint.",
  });
});

// ---------------------------------------------------------------------
// LAN-VISIBILITY HELPER
// ---------------------------------------------------------------------
function getLanAddresses() {
  const interfaces = os.networkInterfaces();
  const addresses = [];

  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name] || []) {
      if (iface.family === "IPv4" && !iface.internal) {
        addresses.push({
          name,
          address: iface.address,
        });
      }
    }
  }

  return addresses;
}

// ---------------------------------------------------------------------
// HTTP SERVER
// ---------------------------------------------------------------------
const server = app.listen(PORT, "0.0.0.0", () => {
  console.log(
    `SafeRoute backend listening on 0.0.0.0:${PORT} (all interfaces)`
  );

  const lanAddresses = getLanAddresses();

  if (lanAddresses.length === 0) {
    console.log(
      "  WARNING: no non-internal IPv4 interface detected — if a physical " +
      "phone can't reach this backend, confirm this machine actually has " +
      "an active Wi-Fi/LAN connection."
    );
  } else {
    console.log(
      "  Reachable from other devices on the same network at:"
    );

    lanAddresses.forEach(({ name, address }) => {
      console.log(
        `    http://${address}:${PORT}  (interface: ${name})`
      );
    });

    console.log(
      "  On your phone's browser, open the /health URL above FIRST, before " +
      "testing the app — if that doesn't load, the problem is network/" +
      "firewall, not this backend's code."
    );
  }

  console.log("  GET /health");
  console.log("  GET /health/db");
  console.log(
    "  GET /api/route?startLat=..&startLon=..&endLat=..&endLon=.."
  );
});

// ---------------------------------------------------------------------
// GRACEFUL SHUTDOWN
// ---------------------------------------------------------------------
const SHUTDOWN_TIMEOUT_MS = Number(
  process.env.SHUTDOWN_TIMEOUT_MS || 10000
);

let shuttingDown = false;

function gracefulShutdown(signal) {
  if (shuttingDown) {
    return;
  }

  shuttingDown = true;

  console.log(
    `[shutdown] received ${signal} — closing server, finishing in-flight requests...`
  );

  const forceExitTimer = setTimeout(() => {
    console.error(
      `[shutdown] still not closed after ${SHUTDOWN_TIMEOUT_MS}ms — forcing exit ` +
        "(some in-flight requests may not have completed)"
    );

    process.exit(1);
  }, SHUTDOWN_TIMEOUT_MS);

  forceExitTimer.unref();

  server.close(() => {
    console.log(
      "[shutdown] HTTP server closed — no more in-flight requests"
    );

    clearTimeout(forceExitTimer);

    process.exit(0);
  });
}

process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT", () => gracefulShutdown("SIGINT"));